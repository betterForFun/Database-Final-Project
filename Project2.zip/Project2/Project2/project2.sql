USE Project2;

-- CREATE TABLE Sections AS 
-- 	SELECT Course_id,
-- 		   Section_number,
--            Course_limite,
--            Teaching_team
-- 	FROM
-- 		section s1
-- 	INNER JOIN teaching_team t1
-- 		ON s1.Course_id = t1.Teaching;
        
CREATE TABLE TA_teaching_team AS 
	SELECT *
	FROM
		ta_teaching t1
	WHERE t1.TA_teaching > 0