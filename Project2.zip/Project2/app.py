import sql as sql
from flask import Flask,request,render_template
from flaskext.mysql import MySQL
from flask_bcrypt import Bcrypt
import hashlib

mysql = MySQL()
app = Flask(__name__)
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = 'leonloveyou'
app.config['MYSQL_DATABASE_DB'] = 'project2'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
mysql.init_app(app)


GlobalEmail = " "
GlobalNumber = 89
GlobalDrop = "Dropped"

@app.route('/')
def login():
    return render_template('rent_record.html')

@app.route('/student', methods = ['POST', 'GET'])
def student():
    if request.method == 'POST':
        email = request.form['email']
        global GlobalEmail
        GlobalEmail = email
        password = request.form['password']
        m = hashlib.md5()
        m.update(password.encode(encoding='utf-8'))
        password = m.hexdigest()
        cursor = mysql.connect().cursor()
        cursor.execute("SELECT * FROM student_hashed s WHERE s.Email ='" + email + "' AND s.password= '" + password + "'")
        data = cursor.fetchone()
        if data is None:
            return "Incorrect Password or Email"
        else:
            return render_template('StudentsOptions.html')
    return render_template('customer.html')

@app.route('/professor', methods = ['POST', 'GET'])
def professor():
    if request.method == 'POST':
        email = request.form['email']
        global GlobalEmail
        GlobalEmail = email
        password = request.form['password']
        m = hashlib.md5()
        m.update(password.encode(encoding='utf-8'))
        password = m.hexdigest()
        cursor = mysql.connect().cursor()
        cursor.execute("SELECT * FROM professors_hashed p WHERE p.Email ='" + email + "' AND p.password= '" + password + "'")
        data = cursor.fetchone()
        if data is None:
            return "Inccorect Email or password!"
        else:
            return render_template('ProfessorOptions.html')
    return render_template('employee.html')


@app.route('/courseInfo', methods = ['POST', 'GET'])
def courseInfo():
    error = None
    cursor = mysql.connect().cursor()
    cursor.execute(
        "SELECT DISTINCT s.Course_id, t.Email, p.Office_address, g.Course_1_Exam_Grade,c.Course_Details FROM enrolled e INNER JOIN Sections s ON e.Courses_1 = s.Course_id OR e.Courses_2 = s.Course_id OR e.Courses_3 = s.Course_id INNER JOIN courses c ON e.Courses_1 = c.courses OR e.Courses_2 = c.courses OR e.Courses_3 = c.courses INNER JOIN professor_teaching t ON s.Teaching_team = t.Teaching_teamid INNER JOIN professor p ON t.Email = p.Email INNER JOIN exam_grade g ON e.Email = g.Email AND (e.Courses_1 = g.Courses_1 OR e.Courses_2 = g.Courses_2 OR e.Courses_3 = g.Courses_3) WHERE Section_number = 1 AND e.Email = '" + GlobalEmail + "'")
    result = cursor.fetchall()
    if request.method == 'POST':
        return render_template('courseInfo.html',error = error,result = result)
    return render_template('courseInfo.html',error = error,result = result)


@app.route('/ChangePassword', methods = ['POST', 'GET'])
def ChangePassword():
    error = None

    if request.method == 'POST':
        conn = mysql.connect()
        old = request.form['old']
        first = request.form['first']
        NewPassword = request.form['password']


        m1 = hashlib.md5()
        m1.update(old.encode(encoding='utf-8'))
        old = m1.hexdigest()
        cursor1 = mysql.connect().cursor()
        cursor1.execute(
            "SELECT * FROM student_hashed s WHERE s.Email ='" + GlobalEmail + "' AND s.password= '" + old + "'")
        data1 = cursor1.fetchone()

        cursor2 = mysql.connect().cursor()
        cursor2.execute(
            "SELECT * FROM student_hashed s WHERE s.Email ='" + GlobalEmail + "' AND s.password= '" + old + "'")
        data2 = cursor2.fetchone()

        if (data1 or data2):
            if(first == NewPassword):
                m = hashlib.md5()
                m.update(NewPassword.encode(encoding='utf-8'))
                NewPassword = m.hexdigest()
                if NewPassword:
                    cursor3 = conn.cursor()
                    cursor3.execute(
                        "UPDATE student_hashed s SET s.password = '" + NewPassword + "'WHERE s.Email = '" + GlobalEmail + "'")
                    conn.commit()
                    render_template('ChangePassword.html')
                    return "PassWord changed"
            else:
                return "please double check your new password"
        else:
            return "inccorect password"


    cursor = mysql.connect().cursor()
    cursor.execute(
        "SELECT s.Full_name,s.Email,s.Age,s.Zip,s.Gender,s.Street,s.Major FROM student s WHERE s.Email = '" + GlobalEmail + "'")
    result = cursor.fetchall()
    return render_template('ChangePassword.html',error = error, result = result)


@app.route('/post', methods = ['POST', 'GET'])
def post():
    error = None
    global GlobalNumber
    GlobalNumber += 1

    if request.method == 'POST':
        coursename = request.form['class']
        content = request.form['post']
        if post:
            conn = mysql.connect()
            cursor4 = conn.cursor()
            cursor4.execute('INSERT INTO post_info (Courses,Post_number,Post,Post_BY) VALUES (%s,%s,%s,%s)',(coursename, GlobalNumber, content, GlobalEmail))
            conn.commit()

    cursor1 = mysql.connect().cursor()
    cursor1.execute(
        "select * from post_info p where p.Courses in (select e.Courses_1 from enrolled e where e.Email = '" + GlobalEmail + "')"
    )
    result1 = cursor1.fetchall()
    cursor2 = mysql.connect().cursor()
    cursor2.execute(
        "select * from post_info p where p.Courses in (select e.Courses_2 from enrolled e where e.Email = '" + GlobalEmail + "')"
    )
    result2 = cursor2.fetchall()
    cursor3 = mysql.connect().cursor()
    cursor3.execute(
        "select * from post_info p where p.Courses in (select e.Courses_3 from enrolled e where e.Email = '" + GlobalEmail + "')"
    )
    result3 = cursor3.fetchall()

    return render_template('Posts.html',error = error,result1 = result1,result2 = result2,result3 = result3)

@app.route('/comment', methods = ['POST', 'GET'])
def comment():
    error = None

    if request.method == 'POST':
        recordid = request.form['recordId']
        pickupId = request.form['pickupId']
        dropoffId = request.form['dropoffId']
        pickupDate = request.form['pickupDate']
        dropoffDate = request.form['dropoffDate']
        startM = request.form['startM']
        endM = request.form['endM']
        dayliyLimit = request.form['dayliyLimit']
        email = request.form['email']
        vin = request.form['vin']
        conn = mysql.connect()
        cursor4 = conn.cursor()
        cursor4.execute('INSERT INTO comment_info (Courses,Post_number,Comment,Comment_By) VALUES (%s,%s,%s,%s)',(coursename, post_number, content, GlobalEmail))
        conn.commit()
    return render_template('rent_record.html',error = error)


@app.route('/p_post', methods = ['POST', 'GET'])
def p_post():
    error = None

    if request.method == 'POST':
        coursename = request.form['class']
        content = request.form['post']
        if post:
            conn = mysql.connect()
            cursor4 = conn.cursor()
            cursor4.execute('INSERT INTO post_info (Courses,Post_number,Post,Post_BY) VALUES (%s,%s,%s,%s)',(coursename, GlobalNumber, content, GlobalEmail))
            conn.commit()

    cursor = mysql.connect().cursor()
    cursor.execute("SELECT * FROM post_info p WHERE p.Courses IN (SELECT s.Course_id FROM Sections s INNER JOIN professor_teaching p ON s.Teaching_team = p.Teaching_teamid WHERE p.Email = '" + GlobalEmail + "')")
    result = cursor.fetchall()

    return render_template('p_posts.html',error = error,result = result)


@app.route('/p_comment', methods = ['POST', 'GET'])
def p_comment():
    error = None

    if request.method == 'POST':
        coursename = request.form['class']
        post_number = request.form['number']
        content = request.form['comment']
        if post:
            conn = mysql.connect()
            cursor4 = conn.cursor()
            cursor4.execute('INSERT INTO comment_info (Courses,Post_number,Comment,Comment_By) VALUES (%s,%s,%s,%s)',(coursename, post_number, content, GlobalEmail))
            conn.commit()


    cursor = mysql.connect().cursor()
    cursor.execute("SELECT * FROM post_info p WHERE p.Courses IN (SELECT s.Course_id FROM Sections s INNER JOIN professor_teaching p ON s.Teaching_team = p.Teaching_teamid WHERE p.Email = '" + GlobalEmail + "')")
    result1 = cursor.fetchall()

    cursor = mysql.connect().cursor()
    cursor.execute("SELECT * FROM comment_info c WHERE c.Courses IN (SELECT s.Course_id FROM Sections s INNER JOIN professor_teaching p ON s.Teaching_team = p.Teaching_teamid WHERE p.Email = '" + GlobalEmail + "')")
    result2 = cursor.fetchall()

    return render_template('p_comment.html',error = error,result1 = result1,result2 = result2)


@app.route('/drop', methods = ['POST', 'GET'])
def drop():
    error = None

    if request.method == 'POST':
        coursename = request.form['class']
        coursenumber = request.form['number']
        if coursename:
            conn = mysql.connect()
            cursor2 = conn.cursor()
            cursor2.execute("UPDATE enrolled e SET e."+coursenumber+" = '" + GlobalDrop + "'WHERE e.Email = '" + GlobalEmail + "'")
            conn.commit()

            conn2 = mysql.connect()
            cursor3 = conn2.cursor()
            cursor3.execute("DELETE FROM post_info p WHERE p.Courses = '" + coursename + "'AND p.Post_By = '" + GlobalEmail + "'")
            conn2.commit()

            conn3 = mysql.connect()
            cursor4 = conn3.cursor()
            cursor4.execute("DELETE FROM comment_info c WHERE c.Courses = '" + coursename + "'AND c.Comment_By = '" + GlobalEmail + "'")
            conn3.commit()

    cursor = mysql.connect().cursor()
    cursor.execute(
        "SELECT DISTINCT s.Course_id, t.Email, p.Office_address, g.Course_1_Exam_Grade,c.Course_Details FROM enrolled e INNER JOIN Sections s ON e.Courses_1 = s.Course_id OR e.Courses_2 = s.Course_id OR e.Courses_3 = s.Course_id INNER JOIN courses c ON e.Courses_1 = c.courses OR e.Courses_2 = c.courses OR e.Courses_3 = c.courses INNER JOIN professor_teaching t ON s.Teaching_team = t.Teaching_teamid INNER JOIN professor p ON t.Email = p.Email INNER JOIN exam_grade g ON e.Email = g.Email AND (e.Courses_1 = g.Courses_1 OR e.Courses_2 = g.Courses_2 OR e.Courses_3 = g.Courses_3) WHERE Section_number = 1 AND e.Email = '" + GlobalEmail + "'")
    result = cursor.fetchall()
    return render_template('drop.html',error = error,result = result)



@app.route('/assignment', methods = ['POST', 'GET'])
def assignment():
    error = None

    if request.method == 'POST':
        coursename = request.form['class']
        sectionnumber = request.form['number']
        Examnumber = request.form['exam']
        Exam_des = request.form['exam_des']
        HWnumber = request.form['hw']
        HW_des = request.form['des']

        if Examnumber:
            conn = mysql.connect()
            cursor2 = conn.cursor()
            cursor2.execute("INSERT INTO exam_info (Courses_id,Course_Section,Exam_number,Exam_des) VALUES (%s,%s,%s,%s)" , (coursename,sectionnumber,Examnumber,Exam_des))
            conn.commit()

        if HWnumber:
            conn = mysql.connect()
            cursor2 = conn.cursor()
            cursor2.execute("INSERT INTO homeworks (Courses_id,Section_number,HW_number,HW_des) VALUES (%s,%s,%s,%s)" , (coursename,sectionnumber,HWnumber,HW_des))
            conn.commit()

    cursor = mysql.connect().cursor()
    cursor.execute("SELECT h.Courses_id,h.Section_number,h.HW_number,h.HW_des FROM homeworks h WHERE h.Courses_id IN (SELECT s.Course_id FROM Sections s INNER JOIN professor_teaching p ON s.Teaching_team = p.Teaching_teamid WHERE p.Email = '" + GlobalEmail + "')")
    result1 = cursor.fetchall()
    cursor = mysql.connect().cursor()
    cursor.execute("SELECT * FROM exam_info e WHERE e.Courses_id IN (SELECT s.Course_id FROM Sections s INNER JOIN professor_teaching p ON s.Teaching_team = p.Teaching_teamid WHERE p.Email = '" + GlobalEmail + "')")
    result2 = cursor.fetchall()

    return render_template('assignment.html',error = error,result1 = result1,result2=result2)


@app.route('/hw_score', methods = ['POST', 'GET'])
def hw_score():
    error = None

    if request.method == 'POST':
        student_email = request.form['email']
        course_id = request.form['course']
        score = request.form['score']
        if student_email:
            conn = mysql.connect()
            cursor2 = conn.cursor()
            cursor2.execute("update hw_grade h set h.Course_1_HW_Grade ='" + score + "'where h.Email = '" + student_email +  "'and h.Courses_1 =  '" + course_id + "'")
            conn.commit()

    cursor = mysql.connect().cursor()
    cursor.execute("SELECT h.Email,h.Courses_1,h.Course_1_HW_Grade FROM hw_grade h WHERE h.Courses_1 in (SELECT s.Course_id FROM Sections s INNER JOIN professor_teaching p ON s.Teaching_team = p.Teaching_teamid WHERE p.Email = '" + GlobalEmail + "')")
    result = cursor.fetchall()
    return render_template('hw_score.html',error = error,result = result)


@app.route('/exam_score', methods = ['POST', 'GET'])
def exam_score():
    error = None

    if request.method == 'POST':
        student_email = request.form['email']
        course_id = request.form['course']
        score = request.form['score']
        if student_email:
            conn = mysql.connect()
            cursor2 = conn.cursor()
            cursor2.execute("update exam_grade h set h.Course_1_EXAM_Grade ='" + score + "'where h.Email = '" + student_email +  "'and h.Courses_1 =  '" + course_id + "'")
            conn.commit()

    cursor = mysql.connect().cursor()
    cursor.execute("SELECT h.Email,h.Courses_1,h.Course_1_EXAM_Grade FROM exam_grade h WHERE h.Courses_1 in (SELECT s.Course_id FROM Sections s INNER JOIN professor_teaching p ON s.Teaching_team = p.Teaching_teamid WHERE p.Email = '" + GlobalEmail + "')")
    result = cursor.fetchall()
    return render_template('exam_score.html',error = error,result = result)


if __name__ == '__main__':
    app.run()
